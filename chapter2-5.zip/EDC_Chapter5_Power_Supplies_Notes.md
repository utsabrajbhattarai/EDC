# EDC — Chapter 5: Power Supplies, Breakdown Diodes, and Voltage References
**Course:** ENEX 151 / EX 151 · TU, IOE · BE (BEI, BCT) I/II
**Sources:** Boylestad (regulator circuits, LM317 design pattern), Floyd (series regulator + protection), Millman–Halkias (stability analysis), Sedra–Smith (zener model, bandgap) + your 4 PYQ papers.
**Diagrams:** web figures in chat — **[FIG-17]** transistor series (emitter-follower) regulator with zener, **[FIG-18]** regulator with current-limiting/overload protection, **[FIG-19]** LM317 adjustable regulator.

---

## Chapter Overview

From wall AC to clean DC: **transformer → rectifier → filter (unregulated) → regulator (zener → transistor series/shunt → feedback-improved → IC)**. The chapter's scoring core is the **series regulator family** and the **LM317 design**.

### 📊 PYQ Frequency Analysis — Chapter 5 = 8–9 marks every year

| Topic | 2081 | 2082 Baishakh | 2082 Bhadra | 2083 | Verdict |
|---|---|---|---|---|---|
| **LM317 variable-regulator design** | ✔ 10–20 V [4] | ✔ 5–15 V [4] | ✔ 10–25 V [4] | ✔ 3–15 V [4] | 🔥 **4/4 — GUARANTEED, only the range changes** |
| Series transistor regulator (working / protection / stability) | ✔ improved + stability expr. [2+2] | ✔ current limiting [4] | ✔ short-circuit/overload protection [5] | ✔ stability factor derivation [4] | 🔥 **4/4 — GUARANTEED, sub-angle rotates** |
| Unregulated / zener supply, references | (foundational only) | | | | 🟢 never standalone |

**Strategy:** ~8 of the 8–9 marks come from exactly two questions every year: **(1) LM317 design** (one formula, plug the range) and **(2) a series-regulator sub-topic** (operation → protection → stability factor → feedback improvement — rotate-prepared below). This is the cheapest guaranteed 8 marks on the paper.

---

## 5.1 Unregulated Power Supply

Chain: **transformer** (step to required amplitude, isolate) → **rectifier** (half-wave / full-wave centre-tap / bridge) → **capacitor filter** → load.
Key quantities: DC output V_dc ≈ V_m − V_r(pp)/2; **ripple factor r = V_r(rms)/V_dc**; for a full-wave + C filter V_r(rms) = I_dc/(4√3·f·C) (Boylestad: 2.4·I_dc/C with I in mA, C in μF), so ripple grows with load current — and V_dc also sags with load and mains fluctuations. **Voltage regulation %VR = (V_NL − V_FL)/V_FL × 100%** — an unregulated supply has poor VR; hence Chapter 5.

## 5.2 Zener-Regulated Power Supply

Circuit: series resistor R_S from unregulated V_i, zener (reverse) across the load. Operating rule: zener holds V_o = V_Z while **I_Z(min) ≤ I_Z ≤ I_Z(max)**, with I_S = (V_i − V_Z)/R_S = I_Z + I_L.
Design: R_S(max) ensuring I_Z ≥ I_Z(min) at V_i(min), I_L(max); check P_Z = V_Z·I_Z(max).
Limits (state them — they motivate §5.4): I_L capped by zener power; regulation degraded by zener dynamic resistance r_z (ΔV_o = r_z·ΔI_Z); R_S wastes power.

## 5.3 Zener Diodes, Bandgap Reference, Constant-Current Diodes 🟢

- **Breakdown physics:** true **zener** (tunneling) < ~5 V, **negative** temp-coefficient; **avalanche** (impact ionization) > ~6 V, **positive** TC; ≈5.6–6.2 V devices nearly zero TC — best references. Model: V_Z + r_z (r_z small ⇒ stiff).
- **Bandgap reference:** adds a PTAT voltage (ΔV_BE = V_T ln n, +TC) to a V_BE (−2 mV/°C) with weights summing to the silicon bandgap ≈ **1.205–1.25 V** ⇒ near-zero TC. It is the internal **1.25 V reference of the LM317** (§5.6) — say this link in the exam.
- **Constant-current diode:** a JFET with gate shorted to source ⇒ pins current at I_DSS once V > V_P — the current-domain dual of the zener.

## 5.4 Transistor Shunt / Series Voltage Regulators 🔥

### A. Series regulator (emitter-follower type) — the base circuit of FOUR PYQs
**[FIG-17]** *Exam spec:* series-pass transistor Q₁ between V_i (collector) and V_o (emitter); zener V_Z from base to ground, fed by R from V_i; load on the emitter.

**Operation:** V_o = **V_Z − V_BE**. Q₁ is an emitter follower: if V_o dips (load ↑ or V_i ↓), V_BE = V_Z − V_o **rises**, Q₁ conducts harder, restoring V_o — continuous self-correction. The pass transistor also multiplies the zener's current capability by β (zener supplies only base current).

**Shunt regulator (contrast, 1–2 marks):** control element **in parallel** with the load (Q across output, R_S in series); V_o = V_Z + V_BE; excess current is shunted. Inherently short-circuit-proof but wasteful; series type is efficient at light load — the mainstream choice.

### B. 🔥 Stability factor of the discrete-transistor series regulator — *PYQ 2083 Q9 [4]*
**Definition:** S_V = ΔV_o/ΔV_i (load fixed) — how much input (line/ripple) variation leaks to the output; want S_V ≪ 1.
**Derivation (simple series regulator):** V_o = V_Z − V_BE. Treat the zener as V_Z0 + r_z. The zener is fed from **V_i** through R, so an input change Δv_i divides between R and r_z:
Δv_Z = Δv_i · r_z/(R + r_z). With V_BE ≈ constant (Δv_BE ≈ 0 for small changes):
> **S_V = ΔV_o/ΔV_i = r_z/(R + r_z)** ∎
Interpretation [the closing mark]: small r_z and large R ⇒ good line rejection; e.g. r_z = 10 Ω, R = 1 kΩ ⇒ S_V ≈ 0.01 (1% feed-through). Improvements: feed R from V_o instead of V_i (pre-regulation), or add feedback (§5.5) which divides S_V further by the loop gain.

## 5.5 Improving Regulator Performance with Feedback 🔥

### A. Feedback (error-amplifier) series regulator — *PYQs 2081 Q13 [2+2], 2082 Bhadra Q9 [5]*
*Exam spec (extend FIG-17):* pass transistor Q₁; **sampling divider R₁–R₂** across V_o; **error amplifier Q₂** (or op-amp) comparing the sample V_o·R₂/(R₁+R₂) at its base against zener reference V_Z at its emitter; Q₂'s collector drives Q₁'s base (through R₃ from V_i).

**Operation [2]:** V_o ↓ ⇒ sample ↓ ⇒ V_BE2 ↓ ⇒ Q₂ conducts less ⇒ Q₁'s base voltage ↑ ⇒ Q₁ conducts more ⇒ V_o restored (and vice-versa). Steady state forces the sample ≈ V_Z + V_BE2:
> **V_o = (V_Z + V_BE2)·(R₁ + R₂)/R₂** — output now *adjustable* (pot in the divider) and independent of the pass device.
**Voltage-stability expression [2] (2081 Q13):** the loop divides the open-loop feed-through by the loop gain: **S_V(closed) ≈ S_V(open)/(1 + A·β_fb) = [r_z/(R+r_z)]·1/(1+Aβ_fb)** — plus lower R_out(closed) = R_out/(1+Aβ_fb). "Improved performance" = better line **and** load regulation by the same factor.

### B. 🔥 Short-circuit / overload (current-limiting) protection — *PYQs 2082 Bhadra Q9 [5], 2082 Baishakh Q12(a) [4]*
**[FIG-18]** *Exam spec:* add a small **sense resistor R_SC in series with the pass transistor's emitter/output**, and a **protection transistor Q₃** with its base–emitter across R_SC and its collector on Q₁'s base.
**How it works:** normal load ⇒ drop I_L·R_SC < 0.7 V ⇒ Q₃ off, regulator unaffected. Overload/short ⇒ drop reaches ≈ 0.7 V ⇒ Q₃ turns on and **steals Q₁'s base drive**, clamping the output current at
> **I_L(max) ≈ V_BE(on)/R_SC ≈ 0.7/R_SC** (e.g. R_SC = 1 Ω ⇒ ~0.7 A limit)
The regulator becomes a constant-current source into the fault; V_o collapses but Q₁ and the load survive; normal operation resumes when the fault clears. (Mention foldback limiting as the refinement that reduces short-circuit dissipation.)

## 5.6 IC Voltage Regulators — the LM317 🔥🔥 (asked EVERY year)

Fixed three-terminal family: 78xx (+V), 79xx (−V) — one line. The star is the **LM317 adjustable regulator**.

**[FIG-19]** *Exam spec:* LM317 with V_i at IN; **R₁ from OUT to ADJ** (standard 240 Ω); **R₂ from ADJ to ground** (pot); C_i/C_o decoupling. The IC holds an internal bandgap **V_REF = 1.25 V between OUT and ADJ**, so I₁ = 1.25/R₁ flows down R₁ into R₂ (plus tiny I_ADJ ≈ 50–100 μA):

> **V_o = V_REF·(1 + R₂/R₁) + I_ADJ·R₂ ≈ 1.25(1 + R₂/R₁) V**

Design recipe (write these two lines, then substitute): choose **R₁ = 240 Ω**; then **R₂ = R₁(V_o/1.25 − 1)**; for a range, compute R₂ at both ends ⇒ **fixed resistor + potentiometer**. Constraints to mention: V_i ≥ V_o(max) + 3 V dropout; I_ADJ term negligible.

### 🔥 All four PYQ designs (R₁ = 240 Ω throughout)

| PYQ | Range | R₂ at V_min | R₂ at V_max | Implementation |
|---|---|---|---|---|
| 2083 Q10 [4] | **3–15 V** | 240(3/1.25−1) = **336 Ω** | 240(15/1.25−1) = **2640 Ω** | 336 Ω fixed (≈330 Ω) + **2.3 kΩ pot** (≈2.5 k std) |
| 2082 Bhadra Q10 [4] | **10–25 V** | 240(8−1) = **1680 Ω** | 240(20−1) = **4560 Ω** | 1.68 kΩ fixed (≈1.8 k) + **2.88 kΩ pot** (≈3 k) |
| 2082 Baishakh Q12(b) [4] | **5–15 V** | 240(4−1) = **720 Ω** | **2640 Ω** | 720 Ω fixed + **1.92 kΩ pot** (≈2 k) |
| 2081 Q12 [4] | **10–20 V** | **1680 Ω** | 240(16−1) = **3600 Ω** | 1.68 kΩ fixed + **1.92 kΩ pot** (≈2 k) |

Each 4-mark answer = FIG-19 circuit + V_o formula (with I_ADJ term stated then neglected) + the two R₂ computations + fixed-plus-pot statement + "V_i must exceed V_o(max) by ≥3 V" (e.g. ≥28 V supply for the 10–25 V design).

---

# Chapter 5 Final Revision

**One-shot summary:** Rectifier-plus-filter supplies are unregulated — ripple and sag with load/line. A zener + R_S clamps V_o = V_Z but is current-limited and only as stiff as r_z. Putting an emitter follower between zener and load (series regulator) gives V_o = V_Z − V_BE with β-times the current, self-correcting because V_BE = V_Z − V_o; its line rejection is S_V = ΔV_o/ΔV_i = r_z/(R+r_z). Feedback (sampling divider + error amplifier against the zener) makes V_o = (V_Z+V_BE2)(R₁+R₂)/R₂ — adjustable — and divides S_V and R_out by (1+Aβ). A sense resistor + clamp transistor adds current limiting at I_max ≈ 0.7/R_SC, protecting against shorts. IC regulators package it all; the LM317 holds 1.25 V across R₁ so V_o = 1.25(1+R₂/R₁)+I_ADJR₂ — every year's design question is this one formula evaluated at the two ends of the requested range.

**Formula sheet:** %VR = (V_NL−V_FL)/V_FL·100 · r = V_r(rms)/V_dc · zener: I_S = (V_i−V_Z)/R_S = I_Z+I_L · series reg: V_o = V_Z−V_BE · shunt: V_o = V_Z+V_BE · **S_V = r_z/(R+r_z)** · feedback: V_o = (V_Z+V_BE2)(R₁+R₂)/R₂; S_V, R_out ÷ (1+Aβ) · **I_L(max) = 0.7/R_SC** · **LM317: V_o = 1.25(1+R₂/R₁)+I_ADJR₂; R₂ = R₁(V_o/1.25−1); R₁ = 240 Ω; dropout ≥3 V**

**Important diagrams:** FIG-17 series regulator 🔴 · feedback regulator with sampler+error amp 🔴 · FIG-18 current-limit add-on 🔴 · FIG-19 LM317 wiring 🔴 (GUARANTEED) · zener supply 🟡 · shunt regulator 🟡

**Important derivations:** S_V = r_z/(R+r_z) (2083) · V_o of the feedback regulator · I_L(max) = 0.7/R_SC logic · LM317 V_o formula from the 1.25 V floating reference. **Results to remember:** 1.25 V, 240 Ω convention, 3 V dropout, 0.7/R_SC.

**Common mistakes:** V_o = V_Z **+** V_BE for the *series* type (that's the shunt) · deriving S_V with the zener fed from V_o but claiming it's the simple circuit (state which topology!) · forgetting I_ADJ·R₂ exists (state, then neglect) · quoting one R₂ for a *range* question (need both ends + pot) · omitting the dropout-voltage remark · putting R_SC where it doesn't sense the load current.

---

# Complete Chapter 5 PYQ Bank

| Year | Q | Question (condensed) | Marks | Topic | Type |
|---|---|---|---|---|---|
| 2083 Baishakh | 9 | Derive the expression for stability factor of a discrete-transistor series regulator. | [4] | Stability factor | Derivation |
| 2083 Baishakh | 10 | Design a variable DC voltage regulator using the LM317 to output (3–15) volts. | [4] | LM317 | Design |
| 2082 Bhadra | 9 | Explain the working principle of a series transistor voltage regulator, accompanied by short-circuit/overload protection. | [5] | Series reg + protection | Theory |
| 2082 Bhadra | 10 | Design a 10–25 V variable DC voltage regulator using LM317 IC. | [4] | LM317 | Design |
| 2082 Baishakh | 12 | Draw series voltage regulator with current limiting circuit and explain how this protection circuit works. Design a voltage regulator to give output voltage from 5 V to 15 V using LM317. | [4+4] | Protection + LM317 | Theory + Design |
| 2081 Ashwin | 12 | Design variable DC voltage regulator using LM317 to get (10–20) volts output. | [4] | LM317 | Design |
| 2081 Ashwin | 13 | Explain the working principle of a series transistor voltage regulator with improved performance and derive an expression for the voltage stability. | [2+2] | Feedback regulator + stability | Theory + Derivation |

# PYQ → What to Study

| PYQ | Topic | Notes Section(s) | Required Skill |
|---|---|---|---|
| 2083 Q9 [4] | Stability factor | **§5.4-B** (zener model §5.3) | Define S_V; r_z/(R+r_z) derivation + interpretation |
| 2083 Q10 [4] | LM317 3–15 V | **§5.6** row 1 | Formula + both R₂ + pot + dropout |
| 2082 Bh Q9 [5] | Series reg + protection | **§5.4-A + §5.5-B** (FIG-17, FIG-18) | Follower action + R_SC/Q₃ clamp + 0.7/R_SC |
| 2082 Bh Q10 [4] | LM317 10–25 V | **§5.6** row 2 | As above (V_i ≥ 28 V remark) |
| 2082 Ba Q12(a) [4] | Current limiting | **§5.5-B** | Circuit + normal/fault operation + I_max |
| 2082 Ba Q12(b) [4] | LM317 5–15 V | **§5.6** row 3 | Formula + both R₂ + pot |
| 2081 Q12 [4] | LM317 10–20 V | **§5.6** row 4 | Formula + both R₂ + pot |
| 2081 Q13 [2+2] | Improved regulator + stability | **§5.5-A** (base §5.4) | Error-amp loop story + V_o formula + S_V/(1+Aβ) |

# Final Coverage Audit
✅ Syllabus 5.1–5.6 all present in order; 5.1–5.3 covered at foundation depth despite no standalone PYQ (Rule 4 — and 5.3's bandgap explains the LM317's 1.25 V, cited in §5.6). ✅ References: Boylestad/Floyd (regulator and protection circuits, LM317 pattern with R₁ = 240 Ω), Millman (stability treatment), Sedra–Smith (zener model r_z, bandgap); conventions flagged (S_V symbol; series vs shunt V_o signs). ✅ All 7 PYQs (9 sub-parts) in sections + bank + mapping; all four LM317 ranges computed; cross-topic Q12 split (a)/(b) mapped separately. ✅ Repeated topics flagged (LM317 4/4 🔥, series-regulator family 4/4 🔥); priorities assigned. *End of Chapter 5.*
