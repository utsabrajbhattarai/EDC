# EDC — Chapter 4: Output Stages and Power Amplifiers
**Course:** ENEX 151 / EX 151 · TU, IOE · BE (BEI, BCT) I/II
**Sources:** Boylestad (power-amplifier chapter — your efficiency formulas and numericals follow it), Sedra–Smith (output-stage classification, class AB biasing), Millman, Floyd + your 4 PYQ papers.
**Diagrams:** web figures in chat — **[FIG-13]** transformer-coupled Class A circuit + load lines, **[FIG-14]** Class B push–pull circuit, **[FIG-15]** crossover distortion / class AB waveforms, **[FIG-16]** tuned amplifier + frequency response.

---

## Chapter Overview

Power amplifiers deliver **watts to real loads** (speakers, antennas, motors). The figure of merit is **conversion efficiency η = P_o(ac)/P_i(dc)**, traded against distortion. Ladder of classes: A (linear, wasteful) → B (efficient, crossover-distorted) → AB (the practical compromise) → tuned/Class-C ideas for RF.

### 📊 PYQ Frequency Analysis — Chapter 4 = 12–13 marks every year

| Topic | 2081 | 2082 Baishakh | 2082 Bhadra | 2083 | Verdict |
|---|---|---|---|---|---|
| Class B: circuit/efficiency derivation or numerical | ✔ push-pull η derivation [5] | ✔ numerical (30 V, 16 Ω, maxima) [5] | ✔ transformer-coupled circuit + η condition [6] | ✔ numerical (20 Vpk, 16 Ω, 30 V) [6] | 🔥 **4/4 — GUARANTEED** |
| Transformer-coupled Class A (circuit, curve, η) | ✔ numerical η [4] | – | – | ✔ derive general+max η [7] | 🔥 2/4 |
| Series-fed Class A η derivation | – | ✔ [4] | – | – | 🟡 1/4 |
| Class AB / crossover distortion | – | – | ✔ [6] | – | 🟡 1/4 |
| Tuned amplifier (circuit, response, bandwidth) | ✔ 3 dB BW [4] | ✔ BW derivation [4] | – | – | 🟡 2/4 |
| Classification / power BJTs | (implied) | – | – | – | 🟢 |

**Strategy:** Class B (both derivation *and* numerical templates) + transformer-coupled Class A + tuned-amplifier bandwidth ≈ the whole 13 marks. All PYQ numericals solved below.

---

## 4.1 Classification of Output Stages

Classified by the **conduction angle** of the output device over one signal cycle:

| Class | Conduction angle | Q-point location | Max η | Distortion | Use |
|---|---|---|---|---|---|
| **A** | 360° | centre of load line | 25% (series-fed) / 50% (transformer) | lowest | small-signal, hi-fi |
| **B** | 180° | at cutoff | **78.5%** | crossover | push–pull output |
| **AB** | 180°–360° (just over 180°) | slightly above cutoff | 50–78.5% | low (crossover removed) | practical audio output |
| **C** | < 180° | below cutoff | >90% | severe (harmonics) | RF with tuned load |

**Exam one-liner:** as the conduction angle drops, efficiency rises and linearity falls — the whole chapter in one sentence.

## 4.2 Class A Output Stage

### A. Series-fed Class A — 🔥 derivation asked *2082 Baishakh Q9 [4]: derive general efficiency*
Circuit: ordinary CE stage, R_L directly in the collector; Q at mid-load-line (I_CQ = V_CC/2R_L for max swing).

**Derivation:**
- **DC input power:** the supply delivers constant I_CQ regardless of signal ⇒ **P_i(dc) = V_CC·I_CQ**
- **AC output power** for peak swing V_p, I_p: **P_o(ac) = V_p·I_p/2 = V_p²/(2R_L)**
- **General efficiency:** η = P_o/P_i = (V_p I_p/2)/(V_CC I_CQ) × 100%
- **Maximum:** best case V_p = V_CC/2, I_p = I_CQ = V_CC/2R_L ⇒ P_o(max) = V_CC²/8R_L; P_i = V_CC·V_CC/2R_L = V_CC²/2R_L ⇒
> **η_max = (V_CC²/8R_L)/(V_CC²/2R_L) = 1/4 = 25%** ∎
Weakness to state: the stage dissipates most at **zero signal** (P_2Q = V_CC·I_CQ).

### B. Transformer-coupled Class A 🔥 — *PYQs 2083 Q8 [7] (circuit + curve + general & max η) and 2081 Q9 [4] (numerical)*
**[FIG-13]** *Exam spec:* CE stage whose collector load is the **primary of a step-down transformer** (turns a = N₁/N₂; reflected load R_L′ = a²R_L); R_L on the secondary. Characteristic-curve sketch: **DC load line nearly vertical at V_CE = V_CC** (winding resistance ≈ 0), **AC load line of slope −1/R_L′ through Q**; V_CE swings **0 → 2V_CC** (inductive kick above the rail!), I_C swings 0 → 2I_CQ.

**General efficiency derivation [for the 7-marker]:**
- P_i(dc) = V_CC·I_CQ (constant).
- P_o(ac) = [(V_CEmax − V_CEmin)·(I_Cmax − I_Cmin)]/8 (peak-to-peak form).
> **η = 50 × [(V_CEmax − V_CEmin)/(V_CEmax + V_CEmin)]² %**  ← general formula (Boylestad form; uses V_CEmax+V_CEmin = 2V_CC and symmetric current swing)
- **Maximum:** full swing V_CEmax = 2V_CC, V_CEmin = 0 ⇒ η_max = 50×(2V_CC/2V_CC)² = **50%** ∎ — double the series-fed value because **no DC power is burned in a collector resistor** (transformer primary ≈ 0 Ω at DC).

**🔥 Worked numerical — 2081 Q9 [4]:** V_CC = 12 V; find η for output peaks V_p = 12 V and 6 V.
- V_p = 12 V: V_CEmax = 24, V_CEmin = 0 ⇒ η = 50×(24/24)² = **50%** (theoretical max).
- V_p = 6 V: V_CEmax = 18, V_CEmin = 6 ⇒ η = 50×(12/24)² = **12.5%**.
*(Equivalent shortcut: η = 50(V_p/V_CC)²%. Observation for the last mark: efficiency collapses quadratically at part-signal — Class A's curse.)*

## 4.3 Class B Output Stage 🔥🔥 (GUARANTEED — every year)

### A. Circuit & operation
**[FIG-14]** *Exam spec:* either (i) **complementary symmetry** pair — npn sources current on positive half-cycles, pnp sinks on negative, both biased exactly at cutoff (V_BB = 0) — or (ii) **transformer-coupled push–pull**: centre-tapped driver transformer splits the signal into antiphase halves driving two npn's; centre-tapped output transformer recombines. Each device conducts **180°**.

### B. 🔴 Efficiency derivation — *PYQs 2081 Q10 [5], 2082 Bhadra Q7 [6]*
Output v_L = V_p sin ωt across R_L; each supply/device delivers half-sinusoid pulses of peak I_p = V_p/R_L.
- **DC input:** average of full-wave-rectified current = 2I_p/π ⇒ **P_i(dc) = V_CC·(2/π)·(V_p/R_L)**
- **AC output:** **P_o(ac) = V_p²/(2R_L)**
- **General efficiency:**
> **η = P_o/P_i = (π/4)·(V_p/V_CC) × 100%** — rises **linearly** with drive
- **Maximum (condition: V_p = V_CC, i.e. rail-to-rail swing, V_CE(sat) ≈ 0):**
> **η_max = π/4 = 78.54%** ∎
- *2082 Bhadra Q7 wording "condition for minimum efficiency":* from η ∝ V_p, efficiency is **minimum (→0) as V_p → 0** (idle/small signals) and maximum 78.5% at V_p = V_CC — answer both directions and you're safe against the intended reading.

### C. Transistor dissipation (needed for 2082 Baishakh Q10)
P_2Q (both devices) = P_i − P_o = (2V_CC V_p)/(πR_L) − V_p²/(2R_L). Maximize over V_p: dP/dV_p = 0 ⇒ **V_p* = 2V_CC/π** ⇒
> **P_2Q(max) = 2V_CC²/(π²R_L)** — note it occurs at *part* drive (V_p ≈ 0.636V_CC), ≈ 40% of P_o(max); per transistor half of this.

### D. 🔥 Worked numerical 1 — *2083 Q7 [6]:* Class B, V_p = 20 V into R_L = 16 Ω, V_CC = 30 V; find P_i, P_o, η.
- I_p = 20/16 = 1.25 A; I_dc = 2I_p/π = 0.796 A
- **P_i(dc) = 30 × 0.796 = 23.9 W**
- **P_o(ac) = V_p²/2R_L = 400/32 = 12.5 W**
- **η = 12.5/23.9 = 52.4%** ✓ (sanity: (π/4)(20/30) = 52.36%)

### E. 🔥 Worked numerical 2 — *2082 Baishakh Q10 [5]:* Class B, V_CC = 30 V, R_L = 16 Ω; find **maximum** input power, output power, and transistor dissipation.
- **P_o(max) = V_CC²/2R_L = 900/32 = 28.1 W** (at V_p = V_CC)
- **P_i(max) = V_CC·2V_CC/(πR_L) = 2×900/(16π) = 35.8 W** (also at V_p = V_CC)
- (η at that point: 28.1/35.8 = 78.5% ✓)
- **P_2Q(max) = 2V_CC²/(π²R_L) = 1800/(9.87×16) = 11.4 W**, occurring at V_p = 2V_CC/π ≈ 19.1 V — **state that dissipation peaks at part drive, not full drive** (the trap of this question).

## 4.4–4.5 Class AB Output Stage and Its Biasing 🔥 — *PYQ 2082 Bhadra Q8 [6]: define crossover distortion; explain how class AB eliminates it*

**[FIG-15]** *Exam spec:* class-B output waveform with a flat **dead-band notch each zero-crossing**; beside it, the class-AB circuit (complementary pair with two forward diodes — or a V_BE multiplier — between the bases).

**Crossover distortion [define, ~2]:** in true class B both devices are biased at cutoff; for |v_in| < V_BE ≈ 0.7 V **neither transistor conducts**, so the output stays at zero around every zero-crossing — a notch (odd-harmonic distortion), worst at small signals.

**Class AB cure [~4]:** pre-bias the bases apart by ≈ 2V_BE so **both devices carry a small quiescent current** and each conducts slightly more than 180°; conduction hands over smoothly with no dead zone.
Biasing methods (syllabus 4.5): (1) **two diodes** in the base chain — bonus: thermal tracking (diode drops fall with T just as V_BE does, stabilizing I_Q); (2) **V_BE multiplier** — transistor with R₁–R₂ across it gives V_CE = V_BE(1 + R₁/R₂), an adjustable "rubber diode"; (3) resistor bias (crude). Cost: small standby dissipation, η slightly below 78.5%.

## 4.6 Power BJTs 🟢
Large-area devices: β low (20–100), care about **maximum ratings** (I_Cmax, V_CEO, P_Dmax at 25 °C with **derating** above), junction temperature T_J = T_A + θ_JA·P_D (thermal-resistance ladder θ_JC + θ_CS + θ_SA with a heat sink), **second breakdown** and the SOA (safe operating area) curve. 2–3 mark readiness.

## 4.7 Transformer-Coupled Push–Pull Stage
= the class-B transformer circuit of §4.3-A(ii) — the 2081 Q10 and 2082 Bhadra Q7 target. Extra points to mention: centre-taps provide phase splitting and recombination; **even harmonics cancel** in the output transformer (flux from the two halves subtracts for even terms); no DC core saturation (opposing quiescent fluxes); can also be run class A/AB.

## 4.8 Tuned Amplifiers 🔥 — *PYQs 2081 Q11 [4] (circuit + response + 3 dB BW) and 2082 Baishakh Q7 [4] (derive bandwidth)*

**[FIG-16]** *Exam spec:* CE/CS stage whose collector load is a **parallel RLC tank**; response = narrow band-pass hump centred at f₀ with the 3-dB points f₁, f₂ marked.

**Analysis/derivation:** gain A(jω) = −g_m·Z_tank(jω) with Z_tank = R ∥ jωL ∥ 1/jωC (R = total tank/effective resistance):
Z(jω) = R / [1 + jQ(ω/ω₀ − ω₀/ω)], where
> **ω₀ = 1/√(LC)  (f₀ = 1/2π√(LC))**,  **Q = R/(ω₀L) = ω₀CR**
At resonance the tank is purely resistive ⇒ **A_max = −g_m R**. The 3-dB (half-power) points occur when |denominator| = √2, i.e. Q(ω/ω₀ − ω₀/ω) = ±1; solving the two frequencies and subtracting:
> **BW = f₂ − f₁ = f₀/Q = 1/(2πRC)** ∎ — and f₀ ≈ √(f₁f₂) (geometric centre).
Class A tuned amplifier = this stage biased class A (linear, for the 2081/2082 wording); mention selectivity S = f₀/BW = Q, and that class B/C tuned versions restore the sine via the tank's flywheel effect (bridge to Class C).

---

# Chapter 4 Final Revision

**One-shot summary:** Output stages trade linearity for efficiency via conduction angle. Series-fed class A idles at I_CQ and caps at η = 25%; transformer coupling removes the DC-resistor loss, swings V_CE to 2V_CC, and reaches 50% (η = 50[(V_CEmax−V_CEmin)/(V_CEmax+V_CEmin)]²%). Class B biases at cutoff, each device conducting 180°: P_i = 2V_CCV_p/πR_L, P_o = V_p²/2R_L ⇒ η = (π/4)(V_p/V_CC), max 78.5% at V_p = V_CC, with device dissipation peaking at V_p = 2V_CC/π (P_2Qmax = 2V_CC²/π²R_L) — but it notches every zero-crossing (crossover distortion), cured by class-AB pre-bias (2V_BE via diodes/V_BE multiplier, thermally tracked). Push–pull transformer versions phase-split/recombine and cancel even harmonics. Power BJTs live inside thermal/SOA limits. A parallel-RLC collector load makes a tuned amplifier: f₀ = 1/2π√(LC), A_max = −g_mR, **BW = f₀/Q = 1/2πRC**.

**Formula sheet:** η definitions · series A: P_i = V_CCI_CQ, η_max = 25% · transformer A: η = 50[(V_CEmax−V_CEmin)/(V_CEmax+V_CEmin)]²% = 50(V_p/V_CC)²%, max 50% · class B: I_dc = 2V_p/πR_L, P_i = 2V_CCV_p/πR_L, P_o = V_p²/2R_L, η = (π/4)(V_p/V_CC), η_max = 78.5%, P_o(max) = V_CC²/2R_L, P_i(max) = 2V_CC²/πR_L, P_2Q(max) = 2V_CC²/π²R_L at V_p = 2V_CC/π · V_BE multiplier: V = V_BE(1+R₁/R₂) · tuned: f₀ = 1/2π√(LC), Q = R/ω₀L = ω₀CR, A_max = −g_mR, BW = f₀/Q = 1/2πRC · T_J = T_A + θ_JAP_D

**Important diagrams:** FIG-13 transformer-A circuit + DC/AC load lines 🔴 · FIG-14 push–pull class B 🔴 · FIG-15 crossover + AB bias 🔴 · FIG-16 tuned amp + band-pass response 🔴 · class table §4.1 🟡

**Important derivations:** series-A 25% · transformer-A general/max η · class-B η (the flagship — reproduce in ≤8 lines) · P_2Q(max) via calculus · BW = f₀/Q. **Results to remember:** 25 / 50 / 78.5%; 2V_CC/π; even-harmonic cancellation.

**Common mistakes:** using I_dc = I_p/π (half-wave value) instead of **2I_p/π** for class B · forgetting V_CE swings to **2V_CC** in transformer coupling · assuming max transistor dissipation occurs at max output (it's at 0.636V_CC) · η formulas mixed between classes · BW = f₀·Q instead of f₀/Q · omitting "each device conducts 180°" in class-B answers.

---

# Complete Chapter 4 PYQ Bank

| Year | Q | Question (condensed) | Marks | Topic | Type |
|---|---|---|---|---|---|
| 2083 Baishakh | 7 | For a class B amplifier providing a 20 V peak signal to a 16 Ω load (speaker) and a power supply of V_CC = 30 V, determine the input power, output power, and circuit efficiency. | [6] | Class B | Numerical |
| 2083 Baishakh | 8 | Draw the circuit diagram and the characteristic curve of a transformer-coupled class A amplifier and derive its general and maximum efficiency. | [7] | Transformer Class A | Derivation |
| 2082 Bhadra | 7 | Draw the circuit diagram of transformer coupled Class B amplifier. Determine the condition for minimum efficiency of Class B amplifier. | [6] | Class B transformer | Theory+Derivation |
| 2082 Bhadra | 8 | Define crossover distortion in a class B amplifier and explain how class AB operation can be used to eliminate it. | [6] | Crossover / AB | Theory |
| 2082 Baishakh | 7 | Derive the expression of bandwidth of class A tuned amplifier. | [4] | Tuned amp BW | Derivation |
| 2082 Baishakh | 9 | Derive general efficiency of series fed class A amplifier. | [4] | Series-fed A | Derivation |
| 2082 Baishakh | 10 | For a class B amplifier using a supply of V_CC = 30 V and driving a load of 16 Ω, determine the maximum input power, maximum output power and maximum power dissipation at transistors. | [5] | Class B maxima | Numerical |
| 2081 Ashwin | 9 | Calculate the efficiency of a transformer coupled Class A amplifier for a supply of 12 V DC and output of V_P = 12 V and 6 V. | [4] | Transformer A | Numerical |
| 2081 Ashwin | 10 | Draw the circuit diagram and the characteristic curve of a transformer coupled class B push-pull amplifier and derive its general efficiency. | [5] | Class B push–pull | Derivation |
| 2081 Ashwin | 11 | Draw the circuit diagram of class A tuned amplifier with its frequency response. Derive its 3 dB bandwidth. | [4] | Tuned amp | Derivation |

# PYQ → What to Study

| PYQ | Topic | Notes Section(s) | Required Skill |
|---|---|---|---|
| 2083 Q7 [6] | Class B numerical | **§4.3-D** (template §4.3-B) | P_i via 2I_p/π; P_o; η |
| 2083 Q8 [7] | Transformer A | **§4.2-B** (+FIG-13) | Circuit + both load lines + general & 50% derivation |
| 2082 Bh Q7 [6] | Class B transformer + η condition | §4.3-A(ii), **§4.3-B**, §4.7 | Circuit + η ∝ V_p argument, both extremes |
| 2082 Bh Q8 [6] | Crossover / AB | **§4.4–4.5** (+FIG-15) | Definition + dead-band cause + 2V_BE cure + bias methods |
| 2082 Ba Q7 [4] | Tuned BW | **§4.8** | Z_tank → Q → BW = f₀/Q = 1/2πRC |
| 2082 Ba Q9 [4] | Series-A η | **§4.2-A** | P_i constant, P_o = V_p²/2R_L → 25% |
| 2082 Ba Q10 [5] | Class B maxima | **§4.3-C,E** | Three maxima + "part-drive dissipation peak" remark |
| 2081 Q9 [4] | Transformer A numerical | **§4.2-B** worked example | η = 50(V_p/V_CC)²% for both amplitudes |
| 2081 Q10 [5] | Push–pull η | §4.3-A(ii), **§4.3-B**, §4.7 | Circuit + composite curve + (π/4)(V_p/V_CC) |
| 2081 Q11 [4] | Tuned amp | **§4.8** (+FIG-16) | Circuit + response + 3 dB derivation |

# Final Coverage Audit
✅ Syllabus 4.1–4.8 all present in order; power BJTs (4.6) and classification (4.1) included though unasked (Rule 4). ✅ References: Boylestad (η formulas & every numerical's method), Sedra–Smith (AB biasing/V_BE multiplier, output-stage classification), Millman/Floyd corroboration; conventions flagged (P_i(dc) means supply power; V_p = load peak). ✅ All 10 PYQs in sections + bank + mapping; both class-B numericals fully solved; ambiguous "minimum efficiency" wording addressed both ways. ✅ Repeated topics (Class B 4/4 🔥, transformer-A 2/4, tuned 2/4) and priorities assigned. *End of Chapter 4.*
