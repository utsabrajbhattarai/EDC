# EDC — Chapter 3: Operational Amplifier Circuits and Oscillators
**Course:** ENEX 151 / EX 151 · TU, IOE · BE (BEI, BCT) I/II
**Sources:** Sedra–Smith (oscillators, current sources, diff amp, active loads), Boylestad (oscillator circuits), Millman–Halkias (feedback/oscillator treatment), Floyd (555 timer) + your 4 PYQ papers.
**Diagrams:** web-search figures shown in chat — **[FIG-6]** Wien bridge, **[FIG-7]** RC phase shift, **[FIG-8]** Colpitts, **[FIG-9]** Hartley, **[FIG-10]** 555 astable + waveforms, **[FIG-11]** Widlar current source, **[FIG-12]** differential amplifier with active (current-mirror) load.

---

## Chapter Overview

Two threads: (1) **oscillators** — amplifiers with positive feedback satisfying the Barkhausen criterion, sorted by their frequency-selective network (RC, LC, crystal) plus the 555 timer as a relaxation oscillator; (2) **IC building blocks** — current mirrors/sources (simple → base-compensated → Widlar), the differential pair, and active loads.

### 📊 PYQ Frequency Analysis — Chapter 3 = exactly 13 marks every year

| Topic | 2081 | 2082 Baishakh | 2082 Bhadra | 2083 | Verdict |
|---|---|---|---|---|---|
| One sinusoidal oscillator (circuit + operation + frequency) | ✔ Colpitts [4] | ✔ Hartley [4] | ✔ RC phase-shift [6] | ✔ Wien bridge [1+5] | 🔥 **4/4 — GUARANTEED, type rotates** |
| Barkhausen criterion (stated inside oscillator Q) | ✔ | (implied) | ✔ | (implied) | 🔥 attached lead-in |
| Current source (Widlar / compensation) | ✔ Widlar R_out [5] | – | ✔ Widlar op.+adv. [5+2] | ✔ base-compensated mirror [5+2] | 🔥 **3/4 — near-guaranteed** |
| 555 astable frequency derivation | ✔ [4] | ✔ [4] | – | – | 🟡 2/4 |
| Differential amplifier, active load | – | ✔ active vs passive gain [5] | – | – | 🟡 1/4 |
| Precision rectifiers / crystal osc / op-amp square-triangle | – | – | – | – | 🟢 never asked (syllabus-complete below) |

**Strategy:** master **all four sinusoidal oscillators** (RC phase-shift, Wien, Colpitts, Hartley — rotation covered each exactly once, so a repeat or crystal is next), **all three current sources**, and the **555 derivation**. That's ~11 of the 13 marks locked.

---

## 3.1 Review of Basic Principles of Sinusoidal Oscillators

### A. Concept
An oscillator converts DC into a periodic AC output **with no input signal**: an amplifier A whose output is fed back through a frequency-selective network β(jω) to its own input, with **positive feedback**. Loop gain L(jω) = A·β(jω).

### B. 🔴 Barkhausen criterion (asked verbatim 2082 Bhadra Q5, 2081 Q6)
Sustained sinusoidal oscillation at ω₀ requires the loop gain to satisfy:
> **1. Magnitude: |A·β(jω₀)| = 1** (unity loop gain)
> **2. Phase: ∠A·β(jω₀) = 0° (or 360°n)** — feedback returns exactly in phase.

Practical notes worth a mark each: start-up requires |Aβ| slightly **> 1** (oscillation grows from noise, amplitude then limited by nonlinearity/AGC); the **phase condition sets the frequency** (only ω₀ satisfies it); the magnitude condition sets the **minimum amplifier gain**.

## 3.2 Op-Amp Square/Triangular Generators and RC Oscillator Circuits

**Square/triangular 🟢 (review):** an op-amp **astable** (Schmitt trigger + RC feedback) makes square waves, T = 2RC·ln((1+β)/(1−β)); cascade an **integrator** to convert square → triangular.

### A. 🔥 RC Phase-Shift Oscillator — *PYQ 2082 Bhadra Q5 [6, incl. Barkhausen]*
**[FIG-7]** *Exam spec:* inverting amplifier (op-amp with R_f, or single CE stage) + **three cascaded high-pass RC sections** from output back to input.

**Operation:** the amplifier contributes **180°**; each RC section contributes ~**60°** at ω₀, totalling 180° → loop phase 360° ✓ Barkhausen.

**Frequency derivation (condensed but complete):** for three identical RC sections the feedback factor is
β(jω) = 1 / [1 − 5α² + jα(6 − α²)], where α = 1/(ωRC).
Phase condition ⇒ imaginary part = 0 ⇒ α² = 6 ⇒ ω₀ = 1/(√6·RC):
> **f₀ = 1/(2πRC√6)**
At ω₀: β = 1/(1 − 5·6) = **−1/29** ⇒ magnitude condition:
> **|A| ≥ 29** (e.g. R_f/R ≥ 29 for the op-amp version)
*(BJT version: f₀ = 1/[2πRC√(6 + 4R_C/R)] — mention as refinement.)*

### B. 🔥 Wien Bridge Oscillator — *PYQ 2083 Q5 [1+5]*
**Part (a) [1] — RC vs LC oscillators by application:** RC oscillators suit **low/audio frequencies** (Hz–100s of kHz) where LC would need impractically large, lossy inductors; LC oscillators suit **high/RF frequencies** (100 kHz–GHz) where small L and C give high Q and stability, and where RC phase networks become inaccurate. (State both halves.)

**Part (b) [5] — Wien bridge.** **[FIG-6]** *Exam spec:* non-inverting op-amp (gain 1 + R₃/R₄); positive-feedback arm = **series R–C (Z₁)** from output feeding a **parallel R–C (Z₂)** to ground; junction → non-inverting input. (The four arms Z₁, Z₂, R₃, R₄ form the "bridge".)

**Operation + mathematics:** β = Z₂/(Z₁+Z₂) with Z₁ = R + 1/jωC, Z₂ = R∥(1/jωC):
> **β(jω) = 1 / [3 + j(ωRC − 1/ωRC)]**
Phase condition ⇒ ωRC = 1/ωRC ⇒
> **f₀ = 1/(2πRC)**, and at f₀, β = **1/3** (maximum, real)
Magnitude condition ⇒ amplifier gain **A = 1 + R₃/R₄ = 3 ⇒ R₃ = 2R₄** (design with slightly more + amplitude stabilization: lamp/diode limiting — mention for the last mark).

## 3.3 LC and Crystal Oscillators

### A. 🔥 Colpitts Oscillator — *PYQ 2081 Q6 [4, incl. Barkhausen]*
**[FIG-8]** *Exam spec:* amplifier (CE BJT or op-amp) with LC tank: inductor L across a **capacitive voltage divider C₁–C₂** (junction of C₁C₂ grounded/at emitter); feedback tapped from the divider.
Tank resonance with the two capacitors in series:
> **C_eq = C₁C₂/(C₁ + C₂)  ⇒  f₀ = 1/(2π√(L·C_eq))**
Feedback fraction β ≈ C₁/C₂ (voltage division across the capacitors); magnitude condition ⇒ amplifier gain ≥ C₂/C₁ (⇒ hfe ≥ C₂/C₁ for BJT). 4-mark answer = Barkhausen statement + circuit + f₀ (+ β remark). **Memory hook: Colpitts = Capacitive divider; Hartley = inductive (H has two 'l's ≈ two Ls).**

### B. 🔥 Hartley Oscillator — *PYQ 2082 Baishakh Q6 [4]*
**[FIG-9]** *Exam spec:* same skeleton but the tank is an **inductive divider L₁–L₂** (tapped coil, mutual inductance M) with a single capacitor C across the whole coil.
**Frequency derivation:** at resonance the net loop reactance is zero; the series inductors (with coupling) give
> **L_eq = L₁ + L₂ + 2M  ⇒  f₀ = 1/(2π√(L_eq·C))**
β ≈ L₁/L₂ (or (L₁+M)/(L₂+M)); gain condition A ≥ L₂/L₁.

### C. Crystal oscillators 🟢 (syllabus 3.3, never asked)
Quartz crystal = electromechanical resonator modeled as series RLC (motional) ∥ parallel C₀; **extremely high Q (10⁴–10⁶)** ⇒ excellent frequency stability (ppm). Series resonance f_s = 1/(2π√(L_sC_s)), parallel (antiresonance) slightly above. Used in place of the LC tank (e.g., Pierce circuit) wherever accuracy matters (clocks, μP, RF carriers). Prepare 2–4 marks.

## 3.4 Integrated-Circuit Timers — the 555 🔥 *PYQs 2081 Q7 [4], 2082 Baishakh Q11 [4]*

**[FIG-10]** *Exam spec:* 555 internals = 3×5 kΩ divider (sets V_CC/3 and 2V_CC/3), two comparators, RS flip-flop, discharge transistor, output buffer. Astable wiring: R_A pin7→V_CC... (R_A from V_CC to pin 7, R_B from pin 7 to pins 6+2, C from 6+2 to ground; pin 7 = discharge).

**Operation:** C charges through **R_A + R_B** toward V_CC; when v_C hits **2V_CC/3** the upper comparator resets the FF → output LOW, discharge transistor ON → C discharges through **R_B** into pin 7; at **V_CC/3** the lower comparator sets the FF → output HIGH; repeat. Draw v_C (exponential between V_CC/3 and 2V_CC/3) and the square output.

**🔴 Frequency derivation (the whole 4 marks):** exponential charging law v(t) = V_final + (V_init − V_final)e^(−t/τ).
- **Charge (output HIGH):** V_init = V_CC/3, V_final = V_CC, τ₁ = (R_A+R_B)C. Set v(t_H) = 2V_CC/3: 
 2/3 = 1 − (2/3)e^(−t_H/τ₁) ⇒ e^(−t_H/τ₁) = 1/2 ⇒ **t_H = 0.693(R_A+R_B)C**
- **Discharge (output LOW):** from 2V_CC/3 toward 0 with τ₂ = R_B·C; reaches V_CC/3 when e^(−t_L/τ₂) = 1/2 ⇒ **t_L = 0.693·R_B·C**
> **T = t_H + t_L = 0.693(R_A + 2R_B)C  ⇒  f = 1.44/[(R_A + 2R_B)C]**;  Duty cycle D = (R_A+R_B)/(R_A+2R_B) > 50%
Note: because V_CC/3 and 2V_CC/3 both scale with V_CC, **f is independent of V_CC** — a classy closing remark.

## 3.5 Precision Rectifier Circuits 🟢 (never asked)
Problem: a plain diode can't rectify signals < 0.7 V. Solution: put the diode **inside an op-amp's feedback loop** — the op-amp supplies the 0.7 V, so rectification is ideal ("superdiode"). Half-wave: op-amp + diode in feedback (improved two-diode version avoids saturation); full-wave/absolute-value: half-wave stage + summing amplifier. Applications: AC voltmeters, peak detectors, signal processing of mV signals. Prepare 3–4 marks.

## 3.6 Bias Circuits Suitable for IC Design — Current Mirrors 🔥

**Why:** ICs avoid large resistors/capacitors; bias currents are generated once (I_REF) and **copied** by matched transistors.

### A. Simple (two-transistor) current mirror
Q₁ diode-connected carries I_REF = (V_CC − V_BE)/R; Q₂ matched, same V_BE ⇒ same I_C. KCL at the reference node: I_REF = I_C + 2I_B = I_C(1 + 2/β) ⇒
> **I_O = I_REF / (1 + 2/β)** — error ≈ **2/β** (≈2% at β=100), plus Early-effect error (V_CE mismatch), R_out = r_o.

### B. 🔥 Base-current-compensated mirror — *PYQ 2083 Q6 [5+2]: "explain how a base-current compensation circuit reduces the difference between I_O and I_REF"*
Add emitter-follower **Q₃** between the collector and bases of Q₁, Q₂: Q₃'s emitter feeds both bases, its base draws only (2I_B)/(β₃+1) from the reference node.
**Derivation [5]:** I_REF = I_C + 2I_B/(β+1) = I_C[1 + 2/(β(β+1))] ⇒
> **I_O = I_REF / [1 + 2/(β² + β)] ≈ I_REF(1 − 2/β²)**
**[2] Interpretation:** the mismatch shrinks from **2/β to ≈2/β²** (0.02% at β = 100) because Q₃'s current gain divides the stolen base current by (β+1). Nearly perfect copying.

### C. Other IC bias ideas (one line each): cascode mirror (raises R_out to ~βr_o), Wilson mirror (feedback, R_out ≈ βr_o/2 + compensation), multiple-output mirrors, V_BE-based references. 🟢

## 3.7 The Widlar Current Source 🔥 *PYQs 2082 Bhadra Q6 [5+2], 2081 Q8 [5]*

**[FIG-11]** *Exam spec:* simple mirror + a resistor **R_E in the emitter of the output transistor Q₂** only.

**Operation + derivation [5]:** KVL around the two base–emitter loops: V_BE1 = V_BE2 + I_O·R_E. Using V_BE = V_T ln(I/I_S) with matched devices:
> **V_T·ln(I_REF/I_O) = I_O·R_E** — the Widlar design equation (transcendental; solve iteratively or for R_E directly).
Design use: to copy **microampere** currents. Example: I_REF = 1 mA, I_O = 10 μA ⇒ R_E = V_T ln(100)/10 μA = 25 mV×4.605/10 μA ≈ **11.5 kΩ** — versus ~575 kΩ if you tried to generate 10 μA with a plain resistor mirror ⇒ huge silicon-area saving.

**Advantages over the simple mirror [2]:** (1) generates very **small currents with modest resistor values** (IC-friendly); (2) R_E is emitter degeneration ⇒ much **higher output resistance**:
> **R_out ≈ r_o2·[1 + g_m2(R_E ∥ r_π2)]** ≫ r_o — *PYQ 2081 Q8 asks this derivation:* apply a test source at the output; R_E∥r_π in the emitter raises the resistance seen at the collector by the factor (1+g_m R_E′) (standard degenerated-collector result; sketch the small-signal circuit, write KCL at emitter node, eliminate v_π). Also better mismatch/temperature behaviour.

## 3.8 The Differential Amplifier

Emitter-coupled pair Q₁–Q₂ over a tail current source I_EE. Differential input v_d = v₁−v₂ splits I_EE: each collector signal current = **±g_m·v_d/2** (g_m at I_C = I_EE/2). Definitions: A_d (differential gain), A_cm (common-mode gain, ≈ −R_C/2R_EE), **CMRR = A_d/A_cm** (want huge). Passive load R_C: double-ended A_d = g_m R_C; **single-ended A_d = g_m R_C/2** (half the signal is wasted in the unused collector).

## 3.9 Active Loads 🔥 *PYQ 2082 Baishakh Q8 [5]: show gain with active load is twice that with passive load*

**[FIG-12]** *Exam spec:* diff pair Q₁–Q₂ (tail source) with a **pnp current mirror Q₃–Q₄** as the load; single-ended output at the Q₂/Q₄ collectors.

**Proof [5]:**
- **Passive load, single-ended:** i_c2 = g_m v_d/2 into R_C ⇒ |A_v(passive)| = **g_m·R_C/2** — the Q₁-side signal current is discarded.
- **Active (mirror) load:** Q₁'s signal current i_c1 = g_m v_d/2 enters diode-connected Q₃ and is **mirrored by Q₄ into the output node**, where it **adds** to i_c2: i_out = g_m v_d/2 + g_m v_d/2 = **g_m·v_d**. ⇒ |A_v(active)| = g_m·R_L(node).
- Comparing at equal load resistance: the output signal current — hence the gain — is **exactly twice**, because the mirror recovers the otherwise-wasted half. ∎ (Bonus: the node resistance itself is r_o2∥r_o4, so practically A_v = g_m(r_o2∥r_o4), thousands.)

Also: active load = current source in place of R_C ⇒ huge incremental resistance with small DC drop — the standard IC trick.

## 3.10 Output Stages 🟢 (bridge to Chapter 4)
An op-amp's last stage must drive low-impedance loads: emitter/source followers, Class-AB complementary pairs — full treatment in Chapter 4 (§4.1–4.5); here just know *why*: low Z_out, current capability, acceptable efficiency and distortion.

---

# Chapter 3 Final Revision

**One-shot summary:** Positive feedback with |Aβ| = 1 and loop phase 0° (Barkhausen) turns an amplifier into a sinusoidal oscillator; the β-network fixes f₀ — three-section RC (f₀ = 1/2πRC√6, |A| ≥ 29), Wien bridge (f₀ = 1/2πRC, A = 3), Colpitts (capacitive divider, f₀ = 1/2π√(LC_eq)), Hartley (inductive divider, f₀ = 1/2π√(L_eqC)), crystal for ppm stability. The 555 relaxes a capacitor between V_CC/3 and 2V_CC/3: f = 1.44/(R_A+2R_B)C. IC biasing copies I_REF with mirrors: simple (error 2/β) → base-compensated (2/β²) → Widlar (V_T ln(I_REF/I_O) = I_O R_E; μA currents, R_out ≈ r_o(1+g_mR_E′)). The differential pair splits g_m v_d/2 per side; a current-mirror active load recombines both halves, doubling single-ended gain to g_m(r_o∥r_o).

**Formula sheet:** |Aβ|=1, ∠Aβ=0° · f₀(RC-PS)=1/(2πRC√6), |A|≥29 · f₀(Wien)=1/(2πRC), A=3, R₃=2R₄ · f₀(Colpitts)=1/(2π√(LC₁C₂/(C₁+C₂))) · f₀(Hartley)=1/(2π√((L₁+L₂+2M)C)) · 555: t_H=0.693(R_A+R_B)C, t_L=0.693R_BC, f=1.44/((R_A+2R_B)C), D=(R_A+R_B)/(R_A+2R_B) · mirrors: I_O=I_REF/(1+2/β) → /(1+2/β²) · Widlar: V_T ln(I_REF/I_O)=I_OR_E, R_out≈r_o(1+g_m(R_E∥r_π)) · diff: A_d(se,passive)=g_mR_C/2, A_d(active)=g_m(r_o2∥r_o4), CMRR=A_d/A_cm

**Important diagrams:** FIG-6 Wien 🔴 · FIG-7 RC phase-shift 🔴 · FIG-8 Colpitts 🔴 · FIG-9 Hartley 🔴 · FIG-10 555 astable + v_C/output waveforms 🔴 · FIG-11 Widlar 🔴 · FIG-12 diff pair + mirror load 🟡 · crystal model 🟢

**Important derivations:** f₀ of each oscillator (phase-condition method) · 555 t_H/t_L via the exponential law · mirror error 2/β → 2/β² · Widlar equation + R_out · active-load ×2 proof. **Results to remember:** β=1/29 and 1/3 values; D>50% for basic 555 astable.

**Common mistakes:** quoting |Aβ| > 1 as the *steady-state* condition (that's start-up) · mixing up which oscillator has which divider (Colpitts = C's) · forgetting R_A doesn't carry discharge current (t_L has R_B only) · writing Widlar's R_E in the *reference* transistor · claiming active load doubles gain "because r_o is large" (the doubling is the recombined signal current; large r_o is a separate bonus).

---

# Complete Chapter 3 PYQ Bank

| Year | Q | Question (condensed) | Marks | Topic | Type |
|---|---|---|---|---|---|
| 2083 Baishakh | 5 | Main difference between RC and LC oscillator circuits in terms of application? Explain operation of Wien Bridge Oscillator with circuit diagram and necessary mathematical expressions. | [1+5] | Wien bridge | Theory+Derivation |
| 2083 Baishakh | 6 | Explain how a base current compensation circuit reduces the difference between I_O and I_REF in a simple current mirror circuit. | [5+2] | Compensated mirror | Derivation |
| 2082 Bhadra | 5 | State Barkhausen criteria for sinusoidal oscillation. Explain working principle of RC phase shift oscillator with necessary expression and circuit diagram. | [6] | Barkhausen + RC-PS | Theory+Derivation |
| 2082 Bhadra | 6 | With a neat circuit diagram and necessary mathematical expressions, explain the operation of Widlar current source. What is the advantage of Widlar current source over simple current source? | [5+2] | Widlar | Theory+Derivation |
| 2082 Baishakh | 6 | Draw circuit diagram of LC Hartley oscillator. Derive its frequency of oscillation. | [4] | Hartley | Derivation |
| 2082 Baishakh | 8 | Show that the voltage gain of the differential amplifier with active load is twice that with passive load. | [5] | Active load | Proof |
| 2082 Baishakh | 11 | Derive frequency of oscillation of 555 timer Astable Multivibrator. | [4] | 555 astable | Derivation |
| 2081 Ashwin | 6 | State Barkhausen criterion for sinusoidal oscillation. Draw the circuit diagram of Colpitts oscillator and write its frequency of oscillation. | [4] | Barkhausen + Colpitts | Theory |
| 2081 Ashwin | 7 | Derive frequency of oscillation of 555 timer Astable Multivibrator. | [4] | 555 astable | Derivation |
| 2081 Ashwin | 8 | Draw a Widlar Current Source. Derive an expression for an output resistance of Widlar Current Source. | [5] | Widlar R_out | Derivation |

# PYQ → What to Study

| PYQ | Topic | Notes Section(s) | Required Skill |
|---|---|---|---|
| 2083 Q5 [1+5] | RC-vs-LC + Wien | §3.2-B (both boxes) + §3.1-B | Application contrast; β(jω) → f₀ = 1/2πRC, A = 3 |
| 2083 Q6 [5+2] | Compensated mirror | **§3.6-A,B** | KCL error analysis 2/β → 2/β² |
| 2082 Bh Q5 [6] | Barkhausen + RC-PS | §3.1-B + **§3.2-A** | Criterion + 60°×3 story + f₀, |A|≥29 |
| 2082 Bh Q6 [5+2] | Widlar | **§3.7** | KVL loop → design equation + 2 advantages |
| 2082 Ba Q6 [4] | Hartley | **§3.3-B** (+FIG-9) | Circuit + L_eq = L₁+L₂+2M → f₀ |
| 2082 Ba Q8 [5] | Active-load gain ×2 | §3.8 + **§3.9** (+FIG-12) | Signal-current recombination proof |
| 2082 Ba Q11 [4] | 555 | **§3.4** (+FIG-10) | Exponential-law derivation of t_H, t_L, f |
| 2081 Q6 [4] | Barkhausen + Colpitts | §3.1-B + **§3.3-A** (+FIG-8) | Criterion + circuit + f₀ with C_eq |
| 2081 Q7 [4] | 555 | **§3.4** | Same derivation |
| 2081 Q8 [5] | Widlar R_out | **§3.7** (R_out part) | Test-source derivation R_out ≈ r_o(1+g_mR_E′) |

# Final Coverage Audit
✅ Syllabus 3.1–3.10 all present in order; never-asked items (op-amp square/triangle, crystal, precision rectifiers, output-stage bridge) included at readiness depth (Rule 4). ✅ References: Sedra–Smith (mirror error analysis, Widlar, active-load proof, oscillator loop-gain method), Boylestad/Floyd (oscillator circuit forms, 555), Millman (feedback framing); notation unified (V_T ≈ 25 mV, β ≡ h_FE). ✅ All 10 PYQs placed in sections + bank + mapping; cross-topic handling: Barkhausen sub-parts mapped to §3.1-B alongside their oscillator sections; §3.10 cross-references Ch4 for output-stage PYQs. ✅ Repeated topics flagged (oscillator 4/4, current source 3/4, 555 2/4); 🔴🟡🟢 assigned from PYQ evidence. *End of Chapter 3.*
