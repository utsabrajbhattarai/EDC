# EDC — Chapter 2: Field-Effect Transistors (FET)
**Course:** Electronics Device and Circuit (ENEX 151 / EX 151) · TU, IOE · BE (BEI, BCT) I/II
**Sources:** Boylestad–Nashelsky (FET biasing chapters — your PYQ circuits are lifted from here), Sedra–Smith (MOSFET physics, K-convention), Floyd, Millman–Halkias + your 4 PYQ papers.
**Diagrams:** web-search figures shown in the chat (JFET construction · JFET drain/transfer curves · E-MOSFET construction · D-MOSFET construction/characteristics · FET voltage-divider bias) — each flagged below as **[FIG-n]** with an exam drawing spec.

---

## Chapter Overview — Read This First

FETs control drain current with an electric **field** (gate voltage) instead of an injected base current: **voltage-controlled**, one carrier type (**unipolar**), near-infinite input resistance. The chapter's spine:

> **JFET (depleting a built-in channel) → E-MOSFET (inducing a channel through an oxide) → its I–V law → D-MOSFET (both modes) → biasing → DC analysis → CS amplifier → CMOS logic.**

### 📊 PYQ Frequency Analysis (your 4 papers) — FET = exactly 13 marks every year

| Topic | 2081 Ashwin | 2082 Baishakh | 2082 Bhadra | 2083 Baishakh | Verdict |
|---|---|---|---|---|---|
| Construction + working of one FET type (curves + math) | ✔ **E-MOSFET** [7] | ✔ **D-MOSFET** [7] | ✔ **JFET** [6] | ✔ **D-MOSFET** [6] | 🔥 **4/4 — GUARANTEED, device rotates** |
| DC numerical: find I_D, V_DS (voltage-divider bias) | ✔ JFET [6] | ✔ JFET + g_m [6] | ✔ E-MOSFET [7] | ✔ JFET [7] | 🔥 **4/4 — GUARANTEED** |
| Why FET is unipolar | – | – | – | ✔ (inside Ch1 Q1) [part of 1] | 🟡 |

**Strategic conclusions:**
1. 🔥 Prepare the **construction + working + characteristic curves + equations** answer for **all three devices** (JFET, E-MOSFET, D-MOSFET). Rotation so far: E-MOS → D-MOS → JFET → D-MOS. D-MOSFET has hit twice — but all three stay live.
2. 🔥 Master the **voltage-divider FET numerical** cold: Thévenin gate voltage → V_GS = V_G − I_D R_S → Shockley (JFET/D-MOS) or square-law (E-MOS) → quadratic → **reject the invalid root** → V_DS → **pinch-off/saturation check**. Every year, 6–7 marks, all four solved fully below.
3. All four PYQ circuits are Boylestad textbook examples — the marking scheme expects Boylestad's method (analytical or graphical; analytical shown here).

---

## 2.1 Structure and Physical Operation of the Junction Field-Effect Transistor (JFET)

**[FIG-1: "n-channel JFET construction" — web figure in chat.]** *Exam drawing spec:* an n-type silicon bar (channel) between **Drain (top)** and **Source (bottom)**; two heavily doped **p⁺ gate** regions diffused into the sides, tied together as the **Gate**; shade the depletion regions around each p⁺–n junction, drawn **wedge-shaped (wider near the drain)** when V_DS > 0.

### A. Intuition
A JFET is a doped resistor (the channel) whose cross-section is squeezed by the depletion regions of two reverse-biased pn junctions. More reverse gate bias → wider depletion → narrower channel → less current. The gate junction is **always reverse-biased**, so gate current ≈ 0 (nA) and **R_in ≈ 10⁸–10¹⁰ Ω**.

### B. Operation (the 3-stage story the examiner wants — asked 2082 Bhadra Q3 [6])
1. **V_GS = 0, small V_DS:** channel acts as a resistor; I_D rises linearly with V_DS (**ohmic region**). The drain end is more positive → gate–channel reverse bias is larger near the drain → depletion wedges are thicker there.
2. **V_GS = 0, V_DS increased:** the wedges nearly meet at the drain end when **V_DS = −V_P** (magnitude of pinch-off voltage): **pinch-off**. Beyond this, I_D **saturates at I_DSS** (drain–source saturation current) — carriers are swept through the pinched region; extra V_DS drops across it, not the channel.
3. **V_GS negative:** uniform extra squeezing → channel pinches off earlier (at V_DS = V_GS − V_P) and saturates at a lower current. At **V_GS = V_P** (e.g. −4 V) the channel is fully closed: **I_D = 0 (cutoff)**.

**[FIG-2: "JFET drain characteristics + transfer curve" — web figure in chat.]** *Exam drawing spec:* left plot I_D vs V_DS — family of curves for V_GS = 0, −1, −2, … V; mark ohmic region, locus V_DS = V_GS − V_P, saturation (flat) region, I_DSS on the V_GS = 0 curve. Right plot: **transfer characteristic** I_D vs V_GS — parabola from (V_P, 0) to (0, I_DSS).

### C. Equations (mathematical expressions the question demands)

> **Shockley's equation (saturation/pinch-off region):  I_D = I_DSS (1 − V_GS/V_P)²**

| Symbol | Meaning | Notes |
|---|---|---|
| I_DSS | Max drain current, at V_GS = 0 | device datum |
| V_P | Pinch-off voltage (negative for n-channel; also written V_GS(off)) | I_D = 0 at V_GS = V_P |
| Validity | V_P ≤ V_GS ≤ 0 and V_DS ≥ V_GS − V_P | else ohmic region |

**Transconductance:** g_m = dI_D/dV_GS = **g_m0 (1 − V_GS/V_P)**, with **g_m0 = 2 I_DSS / |V_P|**. Equivalent: g_m = (2/|V_P|)·√(I_DSS·I_D).

**Boundary/ohmic law:** I_D ≈ I_DSS[2(1−V_GS/V_P)(V_DS/|V_P|) − (V_DS/|V_P|)²] — mention only.

### 📌 Summary + PYQ Check
- **PYQ 2082 Bhadra Q3 [6]:** *Describe construction and working principle of n-channel JFET with characteristic curves and mathematical expressions* → exactly §2.1 A–C: FIG-1 + 3-stage story + FIG-2 + Shockley + g_m. Marks split ≈ construction 1.5 / operation 2.5 / curves 1 / equations 1.
- **Common mistakes:** forgetting V_P is *negative* in formulas; claiming the gate junction is forward-biased; drawing depletion wedges uniform (they must be wider at the drain).

---

## 2.2 Structure and Physical Operation of the Enhancement-Type MOSFET

**[FIG-3: "n-channel E-MOSFET construction" — web figure in chat.]** *Exam drawing spec:* p-type **substrate (body)**; two n⁺ wells = **Source** and **Drain**; thin **SiO₂ insulating layer** over the gap; **metal/poly Gate** on top of the oxide; note there is **NO built-in channel** between S and D. Label the four terminals (B usually tied to S).

### A. Physical operation (asked 2081 Ashwin Q4 [7])
1. **V_GS = 0:** drain-to-source path = two back-to-back pn junctions → **I_D ≈ 0**. The device is normally-OFF.
2. **V_GS > 0 (small):** the gate–oxide–substrate structure is a capacitor. Positive gate charge first repels holes (depletion), then attracts substrate electrons to the surface.
3. **V_GS ≥ V_t (threshold voltage, ~1–3 V):** enough electrons accumulate to form an **inversion layer** — an induced n-channel connecting the n⁺ wells. Conduction is now possible; larger V_GS ⇒ deeper channel ⇒ more current. The channel is **enhanced** by the gate: hence *enhancement type*.
4. **Increasing V_DS:** the channel is shallower at the drain end (local V_GD smaller). At **V_DS = V_GS − V_t** the drain end pinches off → **saturation**: I_D becomes ~constant, set by V_GS.

Gate current = 0 exactly (insulating oxide) ⇒ **R_in ≈ 10¹⁰–10¹⁵ Ω** — even higher than JFET.

### 📌 PYQ Check
- **2081 Ashwin Q4 [7]:** *construction + working of n-channel enhancement-type MOSFET with necessary diagrams and drain characteristic curve* → FIG-3 + the 4-step story + the curves and square-law of §2.3 below (the two sections together are the full 7-mark answer).

---

## 2.3 Current–Voltage Characteristics of the Enhancement-Type MOSFET

**Drain characteristics** (draw like FIG-2's left plot but curves labeled V_GS = 2, 3, 4… V, all above V_t; boundary parabola V_DS = V_GS − V_t separating **triode/ohmic** from **saturation**). **Transfer curve:** I_D vs V_GS, zero until V_t, then rising parabola.

### The square-law equations 🔴 (the exact K used in PYQ 2082 Bhadra Q4)

> **Triode (V_DS < V_GS − V_t):  I_D = K[2(V_GS − V_t)V_DS − V_DS²]**
> **Saturation (V_DS ≥ V_GS − V_t):  I_D = K(V_GS − V_t)²**

| Symbol | Meaning |
|---|---|
| V_t | Threshold voltage (V); alternative symbol V_GS(th) |
| K | Conduction parameter (mA/V²); K = k′_n(W/L)/2 = μ_nC_ox(W/L)/2 in Sedra–Smith notation |
| V_OV = V_GS − V_t | Overdrive/effective voltage |

**Transconductance (saturation):** g_m = 2K(V_GS − V_t) = 2√(K·I_D).
*(Boylestad's alternative: K computed from a datasheet point, I_D(on) at V_GS(on): K = I_D(on)/(V_GS(on) − V_t)² — state the equivalence if asked.)*

---

## 2.4 The Depletion-Type MOSFET 🔥 (asked TWICE: 2082 Baishakh Q4 [7], 2083 Baishakh Q3 [6])

**[FIG-4: "D-MOSFET construction & characteristics" — web figure in chat.]** *Exam drawing spec:* same as FIG-3 **plus a physically implanted (built-in) n-channel** between the n⁺ wells under the oxide. Symbol: solid channel line (vs the broken line of E-MOSFET).

### A. Construction difference (state it explicitly — it's the first mark)
Identical to the E-MOSFET **except a real n-channel is diffused in at manufacture**, so current flows even at V_GS = 0 (normally-ON, like a JFET) — but the insulated gate allows **both polarities** of V_GS.

### B. Working principle — two modes (the core of the 6–7 mark answer)
- **Depletion mode (V_GS < 0):** negative gate charge induces positive charge in the channel, i.e. **depletes** electrons from it → channel conductivity falls → I_D < I_DSS; at V_GS = V_P the channel is emptied → cutoff. (JFET-like, but electrostatic through the oxide, not junction depletion.)
- **Enhancement mode (V_GS > 0):** positive gate attracts **additional** electrons into the channel → I_D **exceeds I_DSS**. A JFET cannot do this (its gate junction would forward-bias).
- V_DS behaviour (ohmic → pinch-off → saturation) mirrors the JFET.

### C. Characteristics + mathematics
Drain curves: family for V_GS = +2, +1, 0, −1, −2 … V — curves **above and below** the V_GS = 0 (I_DSS) curve. Transfer curve: Shockley parabola **extended into positive V_GS**, passing I_DSS at V_GS = 0.

> **Same Shockley equation governs both modes:  I_D = I_DSS(1 − V_GS/V_P)²** (with V_GS now allowed > 0)
> g_m = g_m0(1 − V_GS/V_P), g_m0 = 2I_DSS/|V_P|

### 📌 PYQ Check + mistakes
- 2083 Q3 [6] and 2082 Baishakh Q4 [7] are word-for-word this section: FIG-4 + both-modes explanation + both characteristic plots + Shockley/g_m. 🔥 REPEATED PYQ TOPIC.
- **Mistakes:** drawing no built-in channel; forgetting the enhancement half of the transfer curve; using the E-MOSFET square law (D-MOSFET uses Shockley).

---

## 2.5 Biasing in MOS/FET Amplifier Circuits

For JFET/D-MOSFET (need V_GS ≤ 0 typically): **fixed bias** (negative V_GG), **self-bias** (R_S generates V_GS = −I_D R_S, gate grounded via R_G), **voltage-divider bias** (V_G from R_1–R_2; V_GS = V_G − I_D R_S — works even though V_G > 0 because I_D R_S exceeds V_G). For E-MOSFET (needs V_GS > V_t): **voltage-divider** and **drain-feedback** (R_G from drain to gate ⇒ V_GS = V_DS) biasing.

**[FIG-5: "FET voltage-divider bias" — web figure in chat.]** *Exam drawing spec:* V_DD top; R_1 (top) and R_2 (bottom) divider to gate; R_D drain→V_DD; R_S source→ground (bypass C_S for AC); coupling caps in/out. This one circuit is the skeleton of **all four numerical PYQs**.

> **Master equations of the divider bias:**
> **V_G = V_DD·R_2/(R_1 + R_2)** (no gate current ⇒ pure divider — the FET advantage)
> **Bias line: V_GS = V_G − I_D·R_S**
> **V_DS = V_DD − I_D(R_D + R_S)**

---

## 2.6 FET/MOSFET Circuits at DC 🔥🔥 — the guaranteed 6–7 mark numerical

### A. Universal analytical procedure (write these steps in the exam)
1. **V_G** from the divider. 2. **Bias line** V_GS = V_G − I_D R_S. 3. Substitute into the device law — **Shockley** (JFET/D-MOS) or **K(V_GS−V_t)²** (E-MOS, assuming saturation). 4. Solve the **quadratic**; keep the root satisfying V_P < V_GS ≤ 0 (JFET) or V_GS > V_t (E-MOS); **state why the other root is rejected** (it violates the device constraint — worth a mark). 5. **V_DS = V_DD − I_D(R_D+R_S)**. 6. **Verify region:** saturation/pinch-off iff **V_DS ≥ V_GS − V_P** (JFET) or **V_DS ≥ V_GS − V_t** (E-MOS). 7. g_m if asked.

### B. 🔥 Worked PYQ 1 — 2083 Baishakh Q4 [7] (JFET; Boylestad's classic 2.1 MΩ/270 kΩ example)
**Given:** V_DD = 16 V, R_1 = 2.1 MΩ, R_2 = 270 kΩ, R_D = 2.4 kΩ, R_S = 1.5 kΩ, V_P = −4 V, I_DSS = 8 mA.
1. V_G = 16×270k/2370k = **1.82 V**
2. Bias line: V_GS = 1.82 − 1.5·I_D (I_D in mA)
3. Shockley: I_D = 8(1 + V_GS/4)² → substitute → 1.125 I_D² − 9.73 I_D + 16.95 = 0
4. Roots: I_D = 2.42 or 6.24 mA. Reject 6.24 (gives V_GS = −7.53 V < V_P — impossible). ⇒ **I_DQ ≈ 2.42 mA**, **V_GSQ = 1.82 − 3.63 = −1.80 V** ✓ (V_P < V_GS < 0)
5. **V_DS = 16 − 2.42m(2.4k+1.5k) = 16 − 9.44 = 6.56 V**
6. Check: V_GS − V_P = −1.80 + 4 = 2.2 V; V_DS = 6.56 > 2.2 ✓ saturation — Shockley valid.

### C. 🔥 Worked PYQ 2 — 2082 Bhadra Q4 [7] (E-MOSFET)
**Given:** V_DD = 10 V, R_1 = R_2 = 11 MΩ (equal divider), R_D = 6 kΩ, R_S = 6 kΩ, V_t = 1 V, K = 0.48 mA/V².
1. V_G = 10×11/22 = **5 V**
2. V_GS = 5 − 6·I_D (mA)
3. Assume saturation: I_D = 0.48(V_GS − 1)² → 17.28 I_D² − 24.04 I_D + 7.68 = 0
4. Roots: 0.50 or 0.89 mA. Reject 0.89 (V_GS = −0.36 V < V_t → device off — contradiction). ⇒ **I_D ≈ 0.5 mA**, **V_GS = 5 − 3 = 2 V** ✓ (> V_t)
5. **V_DS = 10 − 0.5m×12k = 4 V**
6. Check: V_GS − V_t = 1 V; V_DS = 4 > 1 ✓ saturation confirmed. *(This is Sedra–Smith's classic symmetric-divider example.)*

### D. 🔥 Worked PYQ 3 — 2082 Baishakh Q5 [6] (JFET + g_m; Boylestad's 910 k/110 k example)
**Given:** V_DD = 20 V, R_1 = 910 kΩ, R_2 = 110 kΩ, R_D = 2.2 kΩ, R_S = 1.1 kΩ, I_DSS = 10 mA, V_P = −3.5 V. Find I_DQ, V_GSQ, V_DS, g_m.
1. V_G = 20×110/1020 = **2.16 V**
2. V_GS = 2.16 − 1.1·I_D
3. Shockley → 0.988 I_D² − 11.16 I_D + 26.12 = 0
4. Roots: 3.31 or 7.99 mA. Reject 7.99 (V_GS = −6.63 < V_P). ⇒ **I_DQ ≈ 3.31 mA**, **V_GSQ ≈ −1.49 V**
5. **V_DS = 20 − 3.31m(3.3k) = 9.08 V**; (V_S = 3.64 V, V_D = 12.7 V if asked)
6. **g_m:** g_m0 = 2I_DSS/|V_P| = 20m/3.5 = 5.71 mS → **g_m = 5.71m(1 − 1.49/3.5) = 3.28 mS**

### E. 🔥 Worked PYQ 4 — 2081 Ashwin Q5 [6] (JFET + explicit pinch-off check)
**Given:** V_DD = 20 V, R_1 = 1.5 MΩ, R_2 = 330 kΩ, R_D = 2 kΩ, R_S = 1 kΩ, V_P = −5.5 V, I_DSS = 10 mA; capacitors ideal; check pinch-off region.
1. V_G = 20×330/1830 = **3.61 V**
2. V_GS = 3.61 − 1·I_D
3. Shockley → 0.331 I_D² − 7.02 I_D + 27.42 = 0
4. Roots: 5.16 or 16.1 mA. Reject 16.1 (> I_DSS and V_GS < V_P). ⇒ **I_DQ ≈ 5.16 mA**, **V_GSQ ≈ −1.55 V**
5. **V_DS = 20 − 5.16m×3k = 4.53 V**
6. **Pinch-off check (the asked mark):** need V_DS ≥ V_GS − V_P = −1.55 + 5.5 = **3.95 V**. Since 4.53 V > 3.95 V → **YES, operating in the pinch-off (saturation) region** ✓.

**Exam shortcut / observations:** the invalid quadratic root *always* violates V_P < V_GS ≤ 0 (JFET) or V_GS > V_t (E-MOS) — check it in one line, don't agonize. Sanity band: 0 < I_DQ < I_DSS for JFET.

---

## 2.7 MOSFET as an Amplifier (Common Source)

DC-bias at Q in saturation; small-signal model = gate open circuit (r_in ≈ ∞), dependent source g_m·v_gs drain→source, optional r_o.
- **Z_i = R_1 ∥ R_2** (or R_G) — set by biasing resistors only, MΩ-range (the FET selling point)
- **Z_o = R_D ∥ r_o ≈ R_D**
- **A_v = −g_m(R_D ∥ r_o ∥ R_L)** — inverting, moderate (g_m of FETs < g_m of BJTs at same current)
- With unbypassed R_S: A_v = −g_m R_D/(1 + g_m R_S)

🟡 No FET-amplifier PYQ yet in your 4 papers (BJT versions asked instead) — prepare at 4–5 mark depth; it's an untouched syllabus item and a fresh-question candidate.

## 2.8 MOSFET and CMOS as Logic Circuits 🟢

NMOS inverter: driver + load; output low = V_OL when driver ON. **CMOS inverter:** complementary PMOS (source→V_DD) + NMOS (source→GND), gates joined = input, drains joined = output. V_in high → NMOS ON/PMOS OFF → out 0; V_in low → PMOS ON/NMOS OFF → out V_DD. **Only one device conducts in either state ⇒ ~zero static power** — why CMOS owns digital ICs. (No PYQ; 2–4 mark readiness.)

---

# FET Final Revision

**One-shot summary:** A JFET squeezes a built-in channel with reverse-biased junction depletion (normally-ON, V_GS ≤ 0, Shockley law, pinch-off at V_P). An E-MOSFET has no channel until V_GS > V_t induces an inversion layer through the oxide (normally-OFF, square law K(V_GS−V_t)²). The D-MOSFET has a built-in channel *and* an insulated gate ⇒ works in both depletion (V_GS<0) and enhancement (V_GS>0) modes under Shockley's law. All are unipolar, voltage-controlled, ~infinite input resistance. Bias with a voltage divider + R_S: V_GS = V_G − I_D R_S intersected with the device law (quadratic; reject the unphysical root), then V_DS = V_DD − I_D(R_D+R_S) and verify saturation (V_DS ≥ V_GS − V_P or V_GS − V_t). CS amplifier: A_v = −g_m R_D, huge Z_i. CMOS pairs complementary MOSFETs for zero-static-power logic.

**Formula sheet:** Shockley I_D = I_DSS(1−V_GS/V_P)² · g_m = g_m0(1−V_GS/V_P), g_m0 = 2I_DSS/|V_P| · square-law I_D = K(V_GS−V_t)² (sat), K[2(V_GS−V_t)V_DS − V_DS²] (triode) · g_m = 2K(V_GS−V_t) = 2√(KI_D) · V_G = V_DD R_2/(R_1+R_2) · V_GS = V_G − I_D R_S · V_DS = V_DD − I_D(R_D+R_S) · saturation checks V_DS ≥ V_GS−V_P / V_GS−V_t · CS: A_v = −g_m(R_D∥r_o), Z_i = R_1∥R_2

**Important diagrams:** [FIG-1] JFET construction · [FIG-2] JFET drain+transfer curves · [FIG-3] E-MOSFET construction · E-MOS drain/transfer curves · [FIG-4] D-MOSFET construction + two-mode curves · [FIG-5] voltage-divider bias circuit — 🔴 all guaranteed-question material.

**High priority:** device construction/working ×3 (🔥 4/4 papers) · divider-bias numerical (🔥 4/4) · region checks. **Medium:** g_m calc, CS amplifier, biasing variants. **Low:** CMOS logic, ohmic-region law.

**Common mistakes:** sign of V_P · accepting the wrong quadratic root · skipping the saturation/pinch-off check · square law for D-MOSFET · forgetting I_G = 0 makes the divider exact · drawing E-MOSFET with a built-in channel.

**Numerical types:** N1 divider-bias JFET (→ §2.6-B/D/E) · N2 divider-bias E-MOS (→ §2.6-C) · N3 g_m at Q (→ §2.6-D) · N4 self-bias variant (V_G = 0 special case of the same method).

---

# Complete FET PYQ Bank

| Year | Q | Question (condensed, wording preserved) | Marks | Topic | Type |
|---|---|---|---|---|---|
| 2083 Baishakh (Back) | 3 | Describe the construction and working principle of N-Channel D-MOSFET with the help of characteristic curves and mathematical expressions. | [6] | D-MOSFET theory | Theory |
| 2083 Baishakh (Back) | 4 | Find I_D and V_DS for the given circuit. Given: V_P = −4 V, I_DSS = 8 mA. (16 V; 2.1 MΩ/270 kΩ; 2.4 kΩ; 1.5 kΩ) | [7] | JFET DC numerical | Numerical |
| 2082 Bhadra (Reg) | 3 | Describe the construction and working principle of n-channel JFET with the help of characteristic curves and mathematical expressions. | [6] | JFET theory | Theory |
| 2082 Bhadra (Reg) | 4 | Find I_D and V_DS for the circuit shown. Given: V_t = 1 V, K = 0.48 mA/V². (10 V; 11 MΩ/11 MΩ; 6 kΩ; 6 kΩ) | [7] | E-MOSFET DC numerical | Numerical |
| 2082 Baishakh (Back) | 4 | Describe the construction and working principle of n-channel depletion type MOSFET with the help of characteristics curve and mathematical expressions. | [7] | D-MOSFET theory | Theory |
| 2082 Baishakh (Back) | 5 | For the given JFET voltage divider configuration, determine I_DQ, V_GSQ, V_DS and transconductance g_m. (20 V; 910 kΩ/110 kΩ; 2.2 kΩ; 1.1 kΩ; I_DSS = 10 mA, V_P = −3.5 V) | [6] | JFET DC + g_m | Numerical |
| 2081 Ashwin (Reg) | 4 | Describe the construction and working principle of n-channel enhancement-type MOSFET with the help of necessary diagrams and its drain characteristic curve. | [7] | E-MOSFET theory | Theory |
| 2081 Ashwin (Reg) | 5 | Find I_D and V_DS for the following circuit. Given V_P = −5.5 V, I_DSS = 10 mA. Assume capacitors ideal and check whether the transistor is operating in the Pinch-off region or not. (20 V; 1.5 MΩ/330 kΩ; 2 kΩ; 1 kΩ) | [6] | JFET DC + region check | Numerical |

# PYQ → What to Study

| PYQ | Topic | Notes Section(s) | Required Skill |
|---|---|---|---|
| 2083 Q3 [6] | D-MOSFET theory | **§2.4** (+FIG-4); contrast §2.1–2.3 | Construction diff + 2 modes + curves + Shockley/g_m |
| 2083 Q4 [7] | JFET numerical | §2.5, **§2.6-A,B** | Divider → quadratic → root rejection → V_DS → check |
| 2082 Bh Q3 [6] | JFET theory | **§2.1** (+FIG-1, FIG-2) | 3-stage operation + curves + Shockley + g_m |
| 2082 Bh Q4 [7] | E-MOSFET numerical | §2.3, **§2.6-C** | Square-law quadratic + V_GS > V_t root + saturation check |
| 2082 Ba Q4 [7] | D-MOSFET theory | **§2.4** | As 2083 Q3 (7-mark: add symbol + both transfer curves) |
| 2082 Ba Q5 [6] | JFET + g_m | **§2.6-D**; g_m from §2.1-C | Full DC solution + g_m0, g_m |
| 2081 Q4 [7] | E-MOSFET theory | **§2.2 + §2.3** (+FIG-3) | Inversion-layer story + drain curves + square law |
| 2081 Q5 [6] | JFET + pinch-off check | **§2.6-E**; condition §2.1-C | DC solution + explicit V_DS ≥ V_GS − V_P verdict |

# Final Coverage Audit
✅ Syllabus 2.1–2.8 all present in order (2.7, 2.8 covered though never asked — Rule 4). ✅ References: Boylestad (all four PYQ circuits & analytic method, g_m formulas), Sedra–Smith (E-MOSFET physics, K-convention, symmetric-divider example, CMOS), Floyd/Millman corroboration; notation unified (V_P ≡ V_GS(off), V_t ≡ V_GS(th), K ≡ k′W/2L flagged). ✅ All 8 FET PYQs in sections + bank + mapping; all four numericals fully solved with root-rejection and region checks. ✅ 🔥 repeated topics (device theory 4/4, numerical 4/4), priorities and diagram list [FIG-1..5] assigned. *End of Chapter 2.*
